# property insurance > 2024-11-25 12:03pm
https://universe.roboflow.com/dennis-mtgir/property-insurance

Provided by a Roboflow user
License: CC BY 4.0

